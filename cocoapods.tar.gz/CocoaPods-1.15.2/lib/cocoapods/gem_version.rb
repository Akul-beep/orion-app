module Pod
  # The version of the CocoaPods command line tool.
  #
  VERSION = '1.15.2'.freeze unless defined? Pod::VERSION
end
