//
//  main.swift
//  CLITool
//
//  Created by Marius Rackwitz on 3.6.15.
//  Copyright (c) 2015 LJR Software Limited. All rights reserved.
//

import Foundation

println("Hello, World!")

