//
//  CoconutLib_macOS.h
//  CoconutLib-macOS
//
//  Created by Eric Amorde on 10/20/19.
//  Copyright © 2019 CocoaPods. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CoconutLib_macOS.
FOUNDATION_EXPORT double CoconutLib_macOSVersionNumber;

//! Project version string for CoconutLib_macOS.
FOUNDATION_EXPORT const unsigned char CoconutLib_macOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CoconutLib_macOS/PublicHeader.h>


