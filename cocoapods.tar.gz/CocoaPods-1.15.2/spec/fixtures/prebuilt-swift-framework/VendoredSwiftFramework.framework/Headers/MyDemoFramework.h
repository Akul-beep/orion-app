#import <UIKit/UIKit.h>

//! Project version number for MyDemoFramework.
FOUNDATION_EXPORT double VendoredSwiftFrameworkVersionNumber;

//! Project version string for MyDemoFramework.
FOUNDATION_EXPORT const unsigned char VendoredSwiftFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VendoredSwiftFramework/PublicHeader.h>


