

#import "Coffee.h"

@implementation Coffee

@end
