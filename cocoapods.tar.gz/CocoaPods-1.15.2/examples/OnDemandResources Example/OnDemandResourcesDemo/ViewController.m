//
//  ViewController.m
//  OnDemandResourcesDemo
//
//  Created by xiejunyi on 2020/3/17.
//  Copyright © 2020 xiejunyi. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
