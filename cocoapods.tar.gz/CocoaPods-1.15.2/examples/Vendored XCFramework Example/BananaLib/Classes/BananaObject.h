
@import Foundation;

@interface BananaObject: NSObject

@end
