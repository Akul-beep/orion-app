
#import "BananaObject.h"
@import CoconutLib;

@interface BananaObject()
@property (nonatomic, nullable) CoconutObj *obj;
@end

@implementation BananaObject: NSObject

@end
