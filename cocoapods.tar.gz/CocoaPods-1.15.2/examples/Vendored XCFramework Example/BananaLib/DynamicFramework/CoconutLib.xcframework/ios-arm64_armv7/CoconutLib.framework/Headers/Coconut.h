
#import <Foundation/Foundation.h>

/** Coconuts are cool */
@interface CoconutObj : NSObject

- (void)makeCoconuts;
@end
