#import <Foundation/Foundation.h>

//! Project version number for CoconutLib.
FOUNDATION_EXPORT double CoconutLibVersionNumber;

//! Project version string for CoconutLib.
FOUNDATION_EXPORT const unsigned char CoconutLibVersionString[];

#import "Coconut.h"
