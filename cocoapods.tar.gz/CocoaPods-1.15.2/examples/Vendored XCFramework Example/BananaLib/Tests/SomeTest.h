
@import XCTest;

@interface SomeTest: XCTestCase 

@end
