
#import "Coconut.h"

@implementation CoconutObj: NSObject

- (void) makeCoconuts {
    NSLog(@"Making coconuts!");
}
@end
