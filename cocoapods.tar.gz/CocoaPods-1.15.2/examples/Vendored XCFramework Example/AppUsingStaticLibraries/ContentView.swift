//
//  ContentView.swift
//  AppUsingStaticLibraries
//
//  Created by Eric Amorde on 4/11/20.
//  Copyright © 2020 CocoaPods. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
