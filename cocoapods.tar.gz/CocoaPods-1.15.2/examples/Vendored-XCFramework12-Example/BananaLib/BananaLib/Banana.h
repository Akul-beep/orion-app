#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Banana : NSObject

- (void)peel;

@end

NS_ASSUME_NONNULL_END
