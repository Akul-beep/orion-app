#import "Banana.h"

@implementation Banana

- (void)peel {
    NSLog(@"🍌");
}

@end
