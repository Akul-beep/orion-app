#import "Coconut.h"

@implementation Coconut

- (void)makeCoconuts {
    NSLog(@"Making coconuts!");
}

@end
