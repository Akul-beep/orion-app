#import <Foundation/Foundation.h>

//! Project version number for CoconutLib.
FOUNDATION_EXPORT double CoconutLibVersionNumber;

//! Project version string for CoconutLib.
FOUNDATION_EXPORT const unsigned char CoconutLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CoconutLib/PublicHeader.h>

#import "Coconut.h"
