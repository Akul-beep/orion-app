import Foundation

public class ByConfig {
}
