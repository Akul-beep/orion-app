@import XCTest;

@interface Test5 : XCTestCase
@end

@implementation Test5

- (void)testExample {
    XCTAssertTrue(YES);
}

@end
