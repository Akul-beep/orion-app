//
//  ViewController.swift
//  iOS Example
//
//  Created by Dimitris Koutsogiorgas on 8/4/21.
//  Copyright © 2021 AppCenter Example. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
