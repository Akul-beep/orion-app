#import <CustomModuleMapPod/CMM.h>

@interface CMM (PrivateExtension)
@end